import json
import boto3
import pandas as pd
import datetime
import io

COLUMN = ["order_id","customer_id","order_date","amount","status","product_category","region"]

def lambda_handler(event, context):
    s3 = boto3.client("s3")

    bucket = event["detail"]["bucket"]["name"]
    key = event["detail"]["object"]["key"]

    if not key.startswith("bronze/") or not key.endswith(".csv"):
        return {"status": "skipped", "reason": "not a bronze csv"}
    
    output_key = key.replace("bronze/", "silver/").replace(".csv", ".parquet")
    try:
        s3.get_object(Bucket=bucket, Key=output_key)
        return {"status": "duplicate", "output": output_key}
    except s3.exceptions.ClientError:
        pass

    obj = s3.get_object(Bucket=bucket, Key=key)
    df = pd.read_csv(obj["Body"])

    missing = set(COLUMN) - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    df = df.dropna(subset=["order_id", "customer_id"])
    df["amount"] = pd.to_numeric(df["amount"], errors="coerce")
    df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")

    buffer = io.BytesIO()
    df.to_parquet(buffer, index=False, engine='pyarrow') # Pastikan engine tersedia di Layer
    buffer.seek(0)

    s3.put_object(Bucket=bucket, Key=output_key, Body=buffer.getvalue())

    return {
        "statusCode": 200,
        "body": json.dumps(
            {
                "input": key,
                "output": output_key,
                "rows_processed": len(df),
            }
        ),
    }    
